# The Franzl Langiest CLI Tool

[Mei Vater is a Appenzeller.](https://www.youtube.com/watch?v=hx3FwSNF5wA)

![alt text](imgs/franzl.png)