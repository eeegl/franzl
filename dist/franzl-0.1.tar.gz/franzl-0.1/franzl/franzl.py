def main():
    print("I <3 Franzl Lang")

if __name__ == "__main__":
    main()